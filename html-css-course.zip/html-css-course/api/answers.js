let intro = ["i am your robot Api!", "hi i am Api!", "my name is Api",
 "i am your personal assistent Api!", "i am machine, named Api!"];

 let help =["how may i assistant you", "how i can halp you", "what i can do for you?"];

 let names = ["Your name is Martin"];

 let thanks = ["most welcome", "as you wish", "mention not"];

 let closee = ["okay bye bye, Martin!"];

 let intro0 = ["Whats up dog!"];
 
